﻿namespace LibreHardwareMonitor.UI;

public interface IExpandPersistNode
{
    bool Expanded { get; set; }
}